import NavBar from "../components/NavBar";
import CardFullColumnFrame from "../components/CardFullColumnFrame";
import FooterFrame from "../components/FooterFrame";
import "./Kolkasveikia.css";
const Kolkasveikia = () => {
  return (
    <div className="kolkasveikia">
      <NavBar />
      <CardFullColumnFrame />
      <FooterFrame />
    </div>
  );
};

export default Kolkasveikia;
