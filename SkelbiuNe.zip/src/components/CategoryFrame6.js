import "./CategoryFrame6.css";
const CategoryFrame6 = () => {
  return (
    <div className="categoryframe6">
      <div className="categorythumbnailnametext6">Tinklo įranga</div>
      <div className="subcategoriesframe6">
        <i className="cat6subnametext1">Belaidžio tinklo įranga</i>
        <i className="cat6subnametext2">HUB</i>
        <i className="cat6subnametext2">Maršrutizatoriai</i>
        <i className="cat6subnametext2">Modemai</i>
        <i className="cat6subnametext2">Switch</i>
        <i className="cat6subnametext6">Aksesuarai ir kabeliai</i>
        <i className="cat6subnametext2">Kita</i>
      </div>
    </div>
  );
};

export default CategoryFrame6;
