import "./CategoryFrame1.css";
const CategoryFrame1 = () => {
  return (
    <div className="categoryframe1">
      <div className="categorythumbnailnametext1">Kompiuteriai</div>
      <div className="subcategoriesframe1">
        <button className="cat1subnametext1">Nešiojami kompiuteriai</button>
        <i className="cat1subnametext2">Stacionarūs kompiuteriai</i>
        <button className="cat1subnametext3">Serveriai</button>
        <i className="cat1subnametext2">Planšetiniai kompiuteriai</i>
        <i className="cat1subnametext2">Žaidimų kompiuteriai</i>
        <i className="cat1subnametext2">Elektroninės skaityklės</i>
        <i className="cat1subnametext2">Kita</i>
      </div>
    </div>
  );
};

export default CategoryFrame1;
