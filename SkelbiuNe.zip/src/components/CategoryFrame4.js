import "./CategoryFrame4.css";
const CategoryFrame4 = () => {
  return (
    <div className="categoryframe4">
      <div className="categorythumbnailnametext4">Priedai, aksesuarai</div>
      <div className="subcategoriesframe4">
        <i className="cat4subnametext1">
          Įkrovikliai baterijos ir akumuliatoriai
        </i>
        <i className="cat4subnametext2">Adapteriai, kabeliai ir jungtys</i>
        <i className="cat4subnametext2">Atminties kortelės ir usb atmintinės</i>
        <i className="cat4subnametext2">HDD dėžutės ir išoriniai HDD</i>
        <i className="cat4subnametext2">Krepšiai kompiuteriams</i>
        <i className="cat4subnametext2">UPS (NMŠ)</i>
        <i className="cat4subnametext2">Kita</i>
      </div>
    </div>
  );
};

export default CategoryFrame4;
