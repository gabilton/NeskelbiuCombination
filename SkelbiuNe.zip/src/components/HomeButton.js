import "./HomeButton.css";
const HomeButton = () => {
  return (
    <div className="homebutton">
      <div className="homeicon">
        <img className="union-2-icon" alt="" src="/union-2.svg" />
        <img className="union-icon" alt="" src="/union.svg" />
        <img className="intersect-icon" alt="" src="/intersect.svg" />
        <img className="union-3-icon" alt="" src="/union-3.svg" />
      </div>
      <i className="homebuttontext">Ne!Skelbiu</i>
    </div>
  );
};

export default HomeButton;
