import "./CategoryFrame8.css";
const CategoryFrame8 = () => {
  return (
    <div className="categoryframe8">
      <div className="categorythumbnailnametext8">Konsolės</div>
      <div className="subcategoriesframe8">
        <i className="cat8subnametext1">Sony</i>
        <i className="cat8subnametext2">Microsoft</i>
        <i className="cat8subnametext2">Nintendo</i>
        <i className="cat8subnametext2">Sega</i>
        <i className="cat8subnametext2">Priedai ir dalys</i>
        <i className="cat8subnametext2">Paslaugos</i>
        <i className="cat8subnametext2">Kita</i>
      </div>
    </div>
  );
};

export default CategoryFrame8;
