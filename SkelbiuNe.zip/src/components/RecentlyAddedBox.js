import "./RecentlyAddedBox.css";
const RecentlyAddedBox = () => {
  return (
    <div className="recentlyaddedbox">
      <div className="recentlyaddedthumbnailtext">Naujausi skelbimai</div>
      <div className="recentlyaddedcard1">
        <img
          className="recentlyaddedcardpicture1-icon"
          alt=""
          src="/recentlyaddedcardpicture1@2x.png"
        />
        <div className="recentlyaddedcarddescriptionan">
          <div className="recentlyaddeddescriptionframe1">
            <i className="recentlyaddeddescription1">
              Aprasymas , info lalala. Parduodama maximos iskaba.
            </i>
          </div>
          <div className="recentlyaddedtownframe1">
            <i className="recentlyaddedtown1">Miestas</i>
          </div>
        </div>
      </div>
      <div className="recentlyaddedcard1">
        <img
          className="recentlyaddedcardpicture1-icon"
          alt=""
          src="/recentlyaddedcardpicture1@2x.png"
        />
        <div className="recentlyaddedcarddescriptionan">
          <div className="recentlyaddeddescriptionframe1">
            <i className="recentlyaddeddescription2">
              Aprasymas , info lalala. Parduodama maximos iskaba.
            </i>
          </div>
          <div className="recentlyaddedtownframe1">
            <i className="recentlyaddedtown1">Miestas</i>
          </div>
        </div>
      </div>
      <div className="recentlyaddedcard1">
        <img
          className="recentlyaddedcardpicture1-icon"
          alt=""
          src="/recentlyaddedcardpicture1@2x.png"
        />
        <div className="recentlyaddedcarddescriptionan">
          <div className="recentlyaddeddescriptionframe1">
            <i className="recentlyaddeddescription2">
              Aprasymas , info lalala. Parduodama maximos iskaba.
            </i>
          </div>
          <div className="recentlyaddedtownframe1">
            <i className="recentlyaddedtown1">Miestas</i>
          </div>
        </div>
      </div>
      <div className="recentlyaddedcard1">
        <img
          className="recentlyaddedcardpicture1-icon"
          alt=""
          src="/recentlyaddedcardpicture1@2x.png"
        />
        <div className="recentlyaddedcarddescriptionan">
          <div className="recentlyaddeddescriptionframe1">
            <i className="recentlyaddeddescription2">
              Aprasymas , info lalala. Parduodama maximos iskaba.
            </i>
          </div>
          <div className="recentlyaddedtownframe1">
            <i className="recentlyaddedtown1">Miestas</i>
          </div>
        </div>
      </div>
      <div className="recentlyaddedcard1">
        <img
          className="recentlyaddedcardpicture1-icon"
          alt=""
          src="/recentlyaddedcardpicture1@2x.png"
        />
        <div className="recentlyaddedcarddescriptionan">
          <div className="recentlyaddeddescriptionframe1">
            <i className="recentlyaddeddescription2">
              Aprasymas , info lalala. Parduodama maximos iskaba.
            </i>
          </div>
          <div className="recentlyaddedtownframe1">
            <i className="recentlyaddedtown1">Miestas</i>
          </div>
        </div>
      </div>
      <div className="recentlyaddedcard1">
        <img
          className="recentlyaddedcardpicture1-icon"
          alt=""
          src="/recentlyaddedcardpicture1@2x.png"
        />
        <div className="recentlyaddedcarddescriptionan">
          <div className="recentlyaddeddescriptionframe1">
            <i className="recentlyaddeddescription2">
              Aprasymas , info lalala. Parduodama maximos iskaba.
            </i>
          </div>
          <div className="recentlyaddedtownframe1">
            <i className="recentlyaddedtown1">Miestas</i>
          </div>
        </div>
      </div>
      <div className="recentlyaddedcard1">
        <img
          className="recentlyaddedcardpicture1-icon"
          alt=""
          src="/recentlyaddedcardpicture1@2x.png"
        />
        <div className="recentlyaddedcarddescriptionan">
          <div className="recentlyaddeddescriptionframe1">
            <i className="recentlyaddeddescription2">
              Aprasymas , info lalala. Parduodama maximos iskaba.
            </i>
          </div>
          <div className="recentlyaddedtownframe1">
            <i className="recentlyaddedtown1">Miestas</i>
          </div>
        </div>
      </div>
      <div className="recentlyaddedcard1">
        <img
          className="recentlyaddedcardpicture1-icon"
          alt=""
          src="/recentlyaddedcardpicture1@2x.png"
        />
        <div className="recentlyaddedcarddescriptionan">
          <div className="recentlyaddeddescriptionframe1">
            <i className="recentlyaddeddescription2">
              Aprasymas , info lalala. Parduodama maximos iskaba.
            </i>
          </div>
          <div className="recentlyaddedtownframe1">
            <i className="recentlyaddedtown1">Miestas</i>
          </div>
        </div>
      </div>
      <div className="recentlyaddedcard1">
        <img
          className="recentlyaddedcardpicture1-icon"
          alt=""
          src="/recentlyaddedcardpicture1@2x.png"
        />
        <div className="recentlyaddedcarddescriptionan">
          <div className="recentlyaddeddescriptionframe1">
            <i className="recentlyaddeddescription2">
              Aprasymas , info lalala. Parduodama maximos iskaba.
            </i>
          </div>
          <div className="recentlyaddedtownframe1">
            <i className="recentlyaddedtown1">Miestas</i>
          </div>
        </div>
      </div>
      <div className="recentlyaddedcard1">
        <img
          className="recentlyaddedcardpicture1-icon"
          alt=""
          src="/recentlyaddedcardpicture1@2x.png"
        />
        <div className="recentlyaddedcarddescriptionan">
          <div className="recentlyaddeddescriptionframe1">
            <i className="recentlyaddeddescription2">
              Aprasymas , info lalala. Parduodama maximos iskaba.
            </i>
          </div>
          <div className="recentlyaddedtownframe1">
            <i className="recentlyaddedtown1">Miestas</i>
          </div>
        </div>
      </div>
      <div className="recentlyaddedcard1">
        <img
          className="recentlyaddedcardpicture1-icon"
          alt=""
          src="/recentlyaddedcardpicture1@2x.png"
        />
        <div className="recentlyaddedcarddescriptionan">
          <div className="recentlyaddeddescriptionframe1">
            <i className="recentlyaddeddescription2">
              Aprasymas , info lalala. Parduodama maximos iskaba.
            </i>
          </div>
          <div className="recentlyaddedtownframe1">
            <i className="recentlyaddedtown1">Miestas</i>
          </div>
        </div>
      </div>
      <div className="recentlyaddedcard1">
        <img
          className="recentlyaddedcardpicture1-icon"
          alt=""
          src="/recentlyaddedcardpicture1@2x.png"
        />
        <div className="recentlyaddedcarddescriptionan">
          <div className="recentlyaddeddescriptionframe1">
            <i className="recentlyaddeddescription2">
              Aprasymas , info lalala. Parduodama maximos iskaba.
            </i>
          </div>
          <div className="recentlyaddedtownframe1">
            <i className="recentlyaddedtown1">Miestas</i>
          </div>
        </div>
      </div>
      <div className="recentlyaddedcard1">
        <img
          className="recentlyaddedcardpicture1-icon"
          alt=""
          src="/recentlyaddedcardpicture1@2x.png"
        />
        <div className="recentlyaddedcarddescriptionan">
          <div className="recentlyaddeddescriptionframe1">
            <i className="recentlyaddeddescription2">
              Aprasymas , info lalala. Parduodama maximos iskaba.
            </i>
          </div>
          <div className="recentlyaddedtownframe1">
            <i className="recentlyaddedtown1">Miestas</i>
          </div>
        </div>
      </div>
      <div className="recentlyaddedcard1">
        <img
          className="recentlyaddedcardpicture1-icon"
          alt=""
          src="/recentlyaddedcardpicture1@2x.png"
        />
        <div className="recentlyaddedcarddescriptionan">
          <div className="recentlyaddeddescriptionframe1">
            <i className="recentlyaddeddescription2">
              Aprasymas , info lalala. Parduodama maximos iskaba.
            </i>
          </div>
          <div className="recentlyaddedtownframe1">
            <i className="recentlyaddedtown1">Miestas</i>
          </div>
        </div>
      </div>
      <div className="recentlyaddedcard1">
        <img
          className="recentlyaddedcardpicture1-icon"
          alt=""
          src="/recentlyaddedcardpicture1@2x.png"
        />
        <div className="recentlyaddedcarddescriptionan">
          <div className="recentlyaddeddescriptionframe1">
            <i className="recentlyaddeddescription2">
              Aprasymas , info lalala. Parduodama maximos iskaba.
            </i>
          </div>
          <div className="recentlyaddedtownframe1">
            <i className="recentlyaddedtown1">Miestas</i>
          </div>
        </div>
      </div>
    </div>
  );
};

export default RecentlyAddedBox;
