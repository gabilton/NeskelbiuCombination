import "./CategoryFrame7.css";
const CategoryFrame7 = () => {
  return (
    <div className="categoryframe7">
      <div className="categorythumbnailnametext7">Paslaugos, remontas</div>
      <div className="subcategoriesframe7">
        <i className="cat7subnametext1">3D spausdinimas</i>
        <i className="cat7subnametext2">Remontas</i>
        <i className="cat7subnametext2">Spaudinimas ir kopijavimas</i>
        <i className="cat7subnametext2">Supirkimas</i>
        <i className="cat7subnametext2">Kita</i>
      </div>
    </div>
  );
};

export default CategoryFrame7;
