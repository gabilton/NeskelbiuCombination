import "./FavoritesAndHistoyFrame.css";
const FavoritesAndHistoyFrame = () => {
  return (
    <div className="favoritesandhistoyframe">
      <button className="favoritesbutton">
        <img className="favoritesicon" alt="" src="/favoritesicon.svg" />
      </button>
      <button className="favoritesbutton">
        <img className="historyicon" alt="" src="/historyicon.svg" />
      </button>
    </div>
  );
};

export default FavoritesAndHistoyFrame;
