import "./CategoryFrame2.css";
const CategoryFrame2 = () => {
  return (
    <div className="categoryframe2">
      <div className="categorythumbnailnametext2">Išoriniai įrenginiai</div>
      <div className="subcategoriesframe2">
        <i className="cat2subnametext1">Monitoriai</i>
        <i className="cat2subnametext2">
          Projektoriai, skeneriai ir spausdintuvai
        </i>
        <i className="cat2subnametext2">Ausinės ir garso kolonėlės</i>
        <i className="cat2subnametext2">Daugiafunkciniai įrenginiai</i>
        <i className="cat2subnametext2">Klaviatūros, pelės ir web kameros</i>
        <i className="cat2subnametext2">Žaidimų priedai</i>
        <i className="cat2subnametext2">Kita</i>
      </div>
    </div>
  );
};

export default CategoryFrame2;
