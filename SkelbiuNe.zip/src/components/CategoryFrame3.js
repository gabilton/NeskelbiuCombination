import "./CategoryFrame3.css";
const CategoryFrame3 = () => {
  return (
    <div className="categoryframe3">
      <div className="categorythumbnailnametext3">Kompiuterių komponentai</div>
      <div className="subcategoriesframe3">
        <i className="cat3subnametext1">Nešiojamiems kompiuteriams</i>
        <i className="cat3subnametext2">Stacionariems kompiuteriams</i>
        <i className="cat3subnametext2">Kita</i>
      </div>
    </div>
  );
};

export default CategoryFrame3;
