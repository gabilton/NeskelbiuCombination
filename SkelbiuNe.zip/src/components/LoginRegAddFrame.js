import { useState, useCallback } from "react";
import LoginFrame from "./LoginFrame";
import PortalPopup from "./PortalPopup";
import "./LoginRegAddFrame.css";
const LoginRegAddFrame = () => {
  const [isLoginFramePopupOpen, setLoginFramePopupOpen] = useState(false);

  const openLoginFramePopup = useCallback(() => {
    setLoginFramePopupOpen(true);
  }, []);

  const closeLoginFramePopup = useCallback(() => {
    setLoginFramePopupOpen(false);
  }, []);

  return (
    <>
      <div className="loginregaddframe">
        <button className="addnewaddbutton">
          <b className="addnewaddbuttonnametext">Naujas skelbimas</b>
        </button>
        <button className="loginbutton" onClick={openLoginFramePopup}>
          <b className="loginbuttonnametext">Prisijungti</b>
        </button>
        <button className="loginbutton">
          <b className="addnewaddbuttonnametext">Registracija</b>
        </button>
      </div>
      {isLoginFramePopupOpen && (
        <PortalPopup
          overlayColor="rgba(113, 113, 113, 0.3)"
          placement="Centered"
          onOutsideClick={closeLoginFramePopup}
        >
          <LoginFrame onClose={closeLoginFramePopup} />
        </PortalPopup>
      )}
    </>
  );
};

export default LoginRegAddFrame;
